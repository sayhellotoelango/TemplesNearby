module.exports = {
	"extends": ["../.eslintrc.js"],
	"env": {
		"mocha": true
	},
	"rules": {

	}
};
